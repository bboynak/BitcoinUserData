Bitcoin User Data Exercise
===============
This is a `PySpark` exercise for loading, transforming and joining dataframes from 
two file sources.


Introduction
-----------
This application is aiming to help the company `KommatiPara` that deals with bitcoin trading.


They have two dataset; first dataset includes client information and the second dataset contains their financial 
details. Since they are planning to reach out to their clients for a new marketing push, 
the company wants a new dataset containing the emails and some financial information 
of their clients that locate in the `United Kingdom` and the `Netherlands`.

*Note: the data does not represent real client information*

Setup
-----------------


What does it do
---------------
